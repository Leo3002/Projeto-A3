/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TipoTrabalho;

/**
 *
 * @author gabri
 */
public class TipoTrabalho {
    
   private int IDTipoTrabalho;
   private String TipoTrabalho;

    public int getIDTipoTrabalho() {
        return IDTipoTrabalho;
    }

    public void setIDTipoTrabalho(int IDTipoTrabalho) {
        this.IDTipoTrabalho = IDTipoTrabalho;
    }

    public String getTipoTrabalho() {
        return TipoTrabalho;
    }

    public void setTipoTrabalho(String TipoTrabalho) {
        this.TipoTrabalho = TipoTrabalho;
    }
   
   
    
    
    
    
}
