/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FunciProjeto;

import Conexao.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class FunciProjeto {
    //Projeto
    private String NomeProjeto;
    private int IDProjeto;
    private String descricao;
    private int statusProjeto;
    private int IDProjeto1;
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getStatusProjeto() {
        return statusProjeto;
    }

    public void setStatusProjeto(int statusProjeto) {
        this.statusProjeto = statusProjeto;
    }
    
    
    public String getNomeProjeto() {
        return NomeProjeto;
    }

    public void setNomeProjeto(String NomeProjeto) {
        this.NomeProjeto = NomeProjeto;
    }

    public int getIDProjeto() {
        return IDProjeto;
    }

    public void setIDProjeto(int IDProjeto) {
        this.IDProjeto = IDProjeto;
    }
    public int getIDProjeto1() {
        return IDProjeto;
    }

    public void setIDProjeto1(int IDProjeto) {
        this.IDProjeto = IDProjeto;
    }
    
    //Funcionario
    public int getIDFuncionario() {
        return IDFuncionario;
    }

    public void setIDFuncionario(int IDFuncionario) {
        this.IDFuncionario = IDFuncionario;
    }

    public String getNomeFuncionario() {
        return NomeFuncionario;
    }

    public void setNomeFuncionario(String NomeFuncionario) {
        this.NomeFuncionario = NomeFuncionario;
    }

    public String getTelefoneFuncionario() {
        return TelefoneFuncionario;
    }

    public void setTelefoneFuncionario(String TelefoneFuncionario) {
        this.TelefoneFuncionario = TelefoneFuncionario;
    }

    public String getStatusFuncionario() {
        return StatusFuncionario;
    }

    public void setStatusFuncionario(String StatusFuncionario) {
        this.StatusFuncionario = StatusFuncionario;
    }

    public String getDepartamento() {
        return Departamento;
    }

    public void setDepartamento(String Departamento) {
        this.Departamento = Departamento;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
    private int IDFuncionario;
    private String NomeFuncionario;
    private String TelefoneFuncionario;
    private String StatusFuncionario;
    private String Departamento;
    private String funcao;
    
    public void InserirFunci() throws SQLException{
        String SQL = "INSERT INTO funcionario(nome_funci, telefone, statusFunci, id_projeto, departamento, funcao) VALUES(?,?,?,?,?,?)";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, getNomeFuncionario());
            ps.setString(2, getTelefoneFuncionario());
            ps.setString(3, getStatusFuncionario());
            ps.setInt(4, getIDProjeto());
            ps.setString(5, getDepartamento());
            ps.setString(6, getFuncao());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
    
    }
    public void AlterarFunci() throws SQLException{
        String SQL = "UPDATE funcionario SET nome_funci= ?, telefone = ?, statusFunci= ?, id_projeto= ?, departamento= ?, funcao=? WHERE id_funci = ?";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, getNomeFuncionario());
            ps.setString(2, getTelefoneFuncionario());
            ps.setString(3, getStatusFuncionario());
            ps.setInt(4, getIDProjeto());
            ps.setString(5, getDepartamento());
            ps.setString(6, getFuncao());
            ps.setInt(7, getIDFuncionario());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
        
    }
    public void ExcluirFunci() throws SQLException{
        String SQL = "DELETE FROM funcionario WHERE id_funci = ?";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            
            ps.setInt(1, getIDFuncionario());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
        
    }
        
    public List<FunciProjeto> read(){
        DAO dao = new DAO();
        Connection c = dao.obtemConexao();
        PreparedStatement stmt = null;
        ResultSet rs= null;
        String SQL = "SELECT * FROM funcionario";
    
        List<FunciProjeto> funcionarios = new ArrayList<>();
        
        try{
            stmt = c.prepareStatement(SQL);
            rs = stmt.executeQuery();
            while(rs.next()){
                FunciProjeto funcionario = new FunciProjeto();
                funcionario.setIDFuncionario(rs.getInt("id_funci"));
                funcionario.setNomeFuncionario(rs.getString("nome_funci"));
                funcionario.setTelefoneFuncionario(rs.getString("telefone"));
                funcionario.setStatusFuncionario(rs.getString("statusFunci"));
                funcionario.setIDProjeto(rs.getInt("id_projeto"));
                funcionario.setDepartamento(rs.getString("departamento"));
                funcionario.setFuncao(rs.getString("funcao"));
                funcionarios.add(funcionario);
                        
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            DAO.closeBanco(c, stmt, rs);
        }
        return funcionarios;
    }
     public List<FunciProjeto> readBusca(String nome ){
        DAO dao = new DAO();
        Connection c = dao.obtemConexao();
        PreparedStatement stmt = null;
        ResultSet rs= null;
        String SQL = "SELECT * FROM funcionario WHERE nome_funci like ?";
        
    
        List<FunciProjeto> funcionarios = new ArrayList<>();
        
        try{
            stmt = c.prepareStatement(SQL);
            stmt.setString(1, "%"+nome+"%");
            rs = stmt.executeQuery();
            while(rs.next()){
                FunciProjeto funcionario = new FunciProjeto();
                funcionario.setIDFuncionario(rs.getInt("id_funci"));
                funcionario.setNomeFuncionario(rs.getString("nome_funci"));
                funcionario.setTelefoneFuncionario(rs.getString("telefone"));
                funcionario.setStatusFuncionario(rs.getString("statusFunci"));
                funcionario.setIDProjeto(rs.getInt("id_projeto"));
                funcionario.setDepartamento(rs.getString("departamento"));
                funcionario.setFuncao(rs.getString("funcao"));
                funcionarios.add(funcionario);
                        
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            DAO.closeBanco(c, stmt, rs);
        }
        return funcionarios;
    }
    public void InserirProjeto() throws SQLException{
        String SQL = "INSERT INTO projeto(nomeprojeto, descricao, statusProjeto) VALUES(?,?,1)";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, getNomeProjeto());
            ps.setString(2, getDescricao());
            
            
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
    
    }
    public void AlterarProjeto() throws SQLException{
        String SQL = "UPDATE projeto SET nomeprojeto= ?, descricao = ?, statusProjeto= ? WHERE id_projeto = ?";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, getNomeProjeto());
            ps.setString(2, getDescricao());
            ps.setInt(3, getStatusProjeto());
            ps.setInt(4, getIDProjeto());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
        
    }
    public void ExcluirProjeto() throws SQLException{
        String SQL = "DELETE FROM projeto WHERE id_projeto = ?";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            
            ps.setInt(1, getIDProjeto());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
}
    public List<FunciProjeto> read2(){
        DAO dao = new DAO();
        Connection c = dao.obtemConexao();
        PreparedStatement stmt = null;
        ResultSet rs= null;
        String SQL = "SELECT * FROM projeto";
    
        List<FunciProjeto> projetos = new ArrayList<>();
        
        try{
            stmt = c.prepareStatement(SQL);
            rs = stmt.executeQuery();
            while(rs.next()){
                FunciProjeto projeto = new FunciProjeto();
                projeto.setIDProjeto(rs.getInt("id"));
                projeto.setNomeProjeto(rs.getString("nomeprojeto"));
                projeto.setDescricao(rs.getString("descricao"));
                projeto.setStatusProjeto(rs.getInt("statusProjeto"));
                
                projetos.add(projeto);
                        
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            DAO.closeBanco(c, stmt, rs);
        }
        return projetos;
    }
     public List<FunciProjeto> readBusca2(String nome ){
        DAO dao = new DAO();
        Connection c = dao.obtemConexao();
        PreparedStatement stmt = null;
        ResultSet rs= null;
        String SQL = "SELECT * FROM projeto WHERE nomeprojeto like ?";
        
    
        List<FunciProjeto> projetos = new ArrayList<>();
        
        try{
            stmt = c.prepareStatement(SQL);
            stmt.setString(1, "%"+nome+"%");
            rs = stmt.executeQuery();
            while(rs.next()){
                FunciProjeto projeto = new FunciProjeto();
                projeto.setIDProjeto(rs.getInt("id"));
                projeto.setNomeProjeto(rs.getString("nomeprojeto"));
                projeto.setDescricao(rs.getString("descricao"));
                projeto.setStatusProjeto(rs.getInt("statusProjeto"));
                
                projetos.add(projeto);
                        
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            DAO.closeBanco(c, stmt, rs);
        }
        return projetos;
    }
}
