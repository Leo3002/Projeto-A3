/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gerenciamento;

/**
 *
 * @author gabri
 */
public class Gerenciamento {
     private String status;
    
    
    
    
    public String getStatus(){
        return status;
        
    }
    
    public void setStatus(String Status){
        this.status = status;
        
    }
    
}
