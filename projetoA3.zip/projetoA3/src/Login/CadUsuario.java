/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import Conexao.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Alunos
 */
public class CadUsuario {
    

 
    public boolean existe (Usuario usuario) throws SQLException{
        
       
        String sql = "SELECT senha FROM Login WHERE usuario = ? and senha = ?";

        DAO dao = new DAO();
        try (Connection c = dao.obtemConexao()){

            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, usuario.getUsuario());
            ps.setString(2, usuario.getSenha());

            try(ResultSet rs = ps.executeQuery()){
                return rs.next();
            }
        
        }

    }
}