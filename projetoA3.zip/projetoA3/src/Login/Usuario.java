/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import Conexao.DAO;
import FunciProjeto.FunciProjeto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EMERSONCORDEIRODELIM
 */
public class Usuario {
    public Usuario(String login, String senha) {
       this.usu = login;
       this.senha = senha;
    }

    public Usuario(int codigo) {
       this.codigo = codigo;
       
    }
    public Usuario(int codigo, String login, String senha) {
       this.codigo = codigo;
       this.usu = login;
       this.senha = senha;
    }
    public Usuario(){}

    

    public String getUsu() {
        return usu;
    }

    public void setUsu(String usuario) {
        this.usu = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    private String usu;
    private String senha;
   private int codigo;
   private boolean tipoAcesso;
   public String tipo;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean getTipoAcesso() {
        return tipoAcesso;
    }

    public void setTipoAcesso(boolean tipoAcesso) {
        this.tipoAcesso = tipoAcesso;
    }
   
    
   
    public String ValidarSenha(){
        
        
 
        String sql = "SELECT senha, tipoUsu FROM login WHERE usuario = ?";

        DAO dao = new DAO();
        try (Connection c = dao.obtemConexao()){

            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, getUsu());

            ResultSet rs = ps.executeQuery();
            //5: itera sobre o resultado
            String aux = "";
            while (rs.next()){
                senha = rs.getString("senha");
                tipoAcesso = rs.getBoolean("tipoUsu");
                tipo = String.valueOf(tipoAcesso);
                
            }
            
        }   
        catch (Exception e){
            e.printStackTrace();
        }
        
        return senha;
    }
    public boolean ValidarTipo(String login){
        
        
 
        String sql = "SELECT tipoUsu FROM login WHERE usuario = ?";

        DAO dao = new DAO();
        try (Connection c = dao.obtemConexao()){

            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, getUsu());

            ResultSet rs = ps.executeQuery();
            //5: itera sobre o resultado
            String aux = "";
            while (rs.next()){
                tipoAcesso = rs.getBoolean("tipoUsu");
                
                
            }
            
        }   
        catch (Exception e){
            e.printStackTrace();
        }
        
        return tipoAcesso;
    }
   
   public void InserirCreden() throws SQLException{
        String SQL = "INSERT INTO login(usuario, senha, tipoUsu) VALUES(?,?,?)";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, getUsu());
            ps.setString(2, getSenha());
            ps.setBoolean(3,getTipoAcesso());
          
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
    
    }
   public void AlterarCreden() throws SQLException{
        String SQL = "UPDATE login SET usuario= ?, senha = ?, tipoUsu = ? WHERE codigo = ?";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, getUsu());
            ps.setString(2, getSenha());
            ps.setBoolean(3, getTipoAcesso());
            ps.setInt(4, getCodigo());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
        
    }
    public void ExcluirCreden() throws SQLException{
        String SQL = "DELETE FROM login WHERE codigo = ?";
    
        DAO dao = new DAO();
        
        try(Connection c = dao.obtemConexao()){
            PreparedStatement ps = c.prepareStatement(SQL);
            
            ps.setInt(1, getCodigo());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    
        
    }
    public List<Usuario> read(){
        DAO dao = new DAO();
        Connection c = dao.obtemConexao();
        PreparedStatement stmt = null;
        ResultSet rs= null;
        String SQL = "SELECT * FROM login";
    
        List<Usuario> usuarios = new ArrayList<>();
        
        try{
            stmt = c.prepareStatement(SQL);
            rs = stmt.executeQuery();
            while(rs.next()){
                Usuario usu = new Usuario();
                usu.setCodigo(rs.getInt("codigo"));
                usu.setUsu(rs.getString("usuario"));
                usu.setSenha(rs.getString("senha"));
                usu.setTipoAcesso(rs.getBoolean("tipoUsu"));
                
                usuarios.add(usu);
                        
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            DAO.closeBanco(c, stmt, rs);
        }
        return usuarios;
    }
     public List<Usuario> readBusca(String nome ){
        DAO dao = new DAO();
        Connection c = dao.obtemConexao();
        PreparedStatement stmt = null;
        ResultSet rs= null;
        String SQL = "SELECT * FROM funcionario WHERE nome_funci like ?";
        
    
        List<Usuario> usuarios = new ArrayList<>();
        
        try{
            stmt = c.prepareStatement(SQL);
            stmt.setString(1, "%"+nome+"%");
            rs = stmt.executeQuery();
            while(rs.next()){
                Usuario usu = new Usuario();
                usu.setCodigo(rs.getInt("codigo"));
                usu.setUsu(rs.getString("usuario"));
                usu.setSenha(rs.getString("senha"));
                usu.setTipoAcesso(rs.getBoolean("tipoUsu"));
                usuarios.add(usu); 
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            DAO.closeBanco(c, stmt, rs);
        }
        return usuarios;
    }
}
