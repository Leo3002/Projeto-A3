/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

/**
 *
 * @author gabri
 */
public class Data {
    private String Data;
    private double HorarioEntrada;
    private double HorarioSaida;
    
    public String getData(){
        return Data;
    }
    
    public void setData(String Data){
        this.Data = Data;
    }
    
    public double getHorarioEntrada(){
        return HorarioEntrada;
    }
    
    public void setHorarioEntrada(double HorarioSaida){
        this.HorarioEntrada = HorarioEntrada;
    }
    
    public double getHorarioSaida(){
        return HorarioSaida;
    }
    
    public void setHorarioSaida(double HorarioSaida){
        this.HorarioSaida = HorarioSaida;
    }
    
}
