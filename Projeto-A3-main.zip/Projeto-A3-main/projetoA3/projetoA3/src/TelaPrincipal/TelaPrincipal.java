/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TelaPrincipal;

import Conexao.DAO;

/**
 *
 * @author gabri
 */
public class TelaPrincipal {
    private String Data;
    private String Cargo;
    private String NomeFuncionario;
    private int IDFuncionario;
    private double HorarioSaida;
    private String NomeProjeto;
    private String TipoTrabalho;
    private String status;
    
    
    
    DAO dao = new DAO();
    
    
    
}
